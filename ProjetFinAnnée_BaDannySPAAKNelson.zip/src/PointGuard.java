/**
 * Meneur de jeu est au centre est a comme capacité de faire beaucoup de passe
 * (plus que la plupart des autre joueurs)
 */
public class PointGuard extends Guard {
  public PointGuard(String name) {
    super(name);
  }
  
  @Override
  public String toString() {
    return "PG " + super.toString();
  }
}
