public class PowerForward extends Forward {
  public PowerForward(String name) {
    super(name);
  }
  
  @Override
  public String toString() {
    return "PF " + super.toString();
  }
}
